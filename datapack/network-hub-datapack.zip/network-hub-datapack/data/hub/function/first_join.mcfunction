tellraw @s ["",{text:"Welcome! ",color:"gold",bold:true},{text:"Right-click the ",color:"gray"},{text:"Server Menu",color:"gold"},{text:" to switch servers. Lost it? ",color:"gray"},{text:"/trigger menu",color:"yellow",click_event:{action:"suggest_command",command:"/trigger menu"}}]
function hub:give_item
